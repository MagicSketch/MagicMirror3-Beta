
@import 'Skinject.framework/Skinject.js'
@import 'MagicMirror3.framework/MagicMirror.js'
@import 'SketchAsync.framework/SketchAsync.js'
@import 'MagicMirrorUI.js'

var onFlip = function(context) {
//    dlog("onFlip from onuseraction.js");
}


var onOpenDocument = function(context) {

//    dlog("onuseraction.js onOpenDocument " + context);

//
//    var identifier = context.plugin.valueForKey("_identifier");
//    var magicmirror = dispatch_once_per_document("MagicMirrorJS", function() { return MagicMirrorJS(identifier) });
//    magicmirror.onOpenDocument(context);
//
//    var skinject = dispatch_once_per_document("Skinject", function() { return Skinject(identifier) });
//    skinject.onSelectionChanged(context);
//
//    var section = configureSectionHeader(magicmirror, skinject)
//    configureLayerToolbar(magicmirror, skinject, section);

}
