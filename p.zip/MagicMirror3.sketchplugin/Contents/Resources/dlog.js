var dlog = function(message) {
        // do nothing;
};
